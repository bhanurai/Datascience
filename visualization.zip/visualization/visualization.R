library(tidyverse)
library(dplyr)
library(scales)
library(fmsb)
library(ggrepel)

setwd("C:/Users/ACER/OneDrive/Desktop/DatascienceFinal")

euro <- dollar_format(prefix = "\u20ac", big.mark = ",")

#House Prices

Towns_Population = read_csv("New Cleaned Data/clean_Town_population.csv") %>% 
  select(-Year) 
HousePrices = read_csv("New Cleaned Data/cleanhouse_2019-2022.csv", show_col_types = FALSE)

HousePricesclean <- HousePrices %>% 
  select(-PostCode) %>% 
  left_join(Towns_Population, by ="shortPostcode")

HousePricesclean$County[HousePricesclean$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
HousePricesclean$County[HousePricesclean$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"

House_town = HousePricesclean %>% 
  #filter(County=="OXFORDSHIRE"|County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  filter(County=="OXFORDSHIRE"|County=="YORKSHIRE") %>% 
  group_by(Town,District,County,Year) %>% 
  summarise(AveragePrice= mean(Price)) %>% 
  ungroup(Town,District,County,Year) %>%
  na.omit()

write.csv(House_town,"New Cleaned Data\\Town_House.csv",row.names = FALSE)

# BOXPLOT Average house prices (2022)
House_town %>% 
  group_by(District) %>% 
  ggplot(aes(x = District, y = AveragePrice, fill=District)) +
  scale_y_continuous(limits=c(0,2000000), breaks = seq(0,2000000,200000), 
                     label = euro) +
  geom_boxplot() +
  coord_flip() +
  labs(title="2022 house prices by district")

# BARGRAPH houseprices by district (2019-2022)

HousePricesclean %>%
  group_by(District) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = District, y = AveragePrice)) +
  geom_bar(position = "stack",stat = "identity", fill = "red") +
  scale_y_continuous(limits=c(0,5000000),breaks = seq(0, 5000000, 30000),
                     label = euro) +
  geom_text(aes(label = euro(AveragePrice)),
            vjust = -0.25) +
  labs(title = "2019-2022 Average house prices by district") +
  coord_flip()

#LINEGRAPH Average house prices by year (2019-2022)

HousePricesclean %>%
  mutate(Year = as.numeric(Year)) %>%  # Convert Year to numeric if not already
  group_by(Year) %>%
  summarise(AveragePrice = mean(Price)) %>%
  ggplot(aes(x = Year, y = AveragePrice)) +
  geom_line(size = 1.5, color = "pink") +
  geom_text(aes(label = dollar_format()(AveragePrice)), vjust = -0.85) +
  scale_y_continuous(labels = dollar_format(prefix = "$"), breaks = seq(0, 300000, 5000)) +
  scale_x_continuous(breaks = seq(2019, 2022, 1), minor_breaks = NULL) +
  geom_point(size = 2, color = "black") +
  labs(title = "2019-2022 Average house prices by year",
       x = "Year",
       y = "Average Price")

D#-----------------------------------BROADBAND---------------------------------------------------#
library(gridExtra)  
#-----------------------------------BROADBAND------------------------------
Towns = read_csv("New Cleaned Data/clean_Town_population.csv")%>% 
  select(shortPostcode, Town, District, County)
BroadbandCleaned = read_csv("New Cleaned Data/clean_Broadband_Speed.csv", show_col_types = FALSE)

broadband=Towns %>% 
  left_join(BroadbandCleaned,by="shortPostcode")
View(broadband)
#-----------Oxfordshire Broadband speed visualization-----------------------
#Average download speed
broadband %>% 
  group_by(County) %>% 
  ggplot(aes(x = County, y = `Avgdownload`, fill=County)) +
  scale_y_continuous(breaks = seq(0,200,10)) +
  geom_boxplot() +
  labs(title = "Average download speed (Mbit/s) by district", x = "District",
       y = "Average Download Speed (Mbit/s)")+
  coord_flip()
#---------------------------------------BARCHART-------------------------------------
#Separate 

#Oxfordshire-avg download speed 
ggplot(broadband,aes(y=Town)) +
  labs(x="Speeds (Mbits/s)",y="Town",title=" Oxfordshire Average Download Speeds")+
  geom_bar(data=filter(broadband,County=="OXFORDSHIRE"),aes(x=Avgdownload,fill="Average"),stat="Identity")+
  geom_bar(data=filter(broadband,County=="OXFORDSHIRE"),aes(x=Mindownload,fill="Minimum"),stat="Identity")+
  guides(fill=guide_legend("Download Speeds"))


# Yorkshire Broadband Speeds Visualization
ggplot(broadband,aes(y=Town)) +
  labs(x="Speeds (Mbits/s)",y="Town",title=" Yorkshire Broadband Speeds")+
  geom_bar(data=filter(broadband,County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE")
           ,aes(x=Avgdownload,fill="Average"),stat="Identity")+
  geom_bar(data=filter(broadband,County=="YORKSHIRE" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE")
           ,aes(x=Mindownload,fill="Minimum"),stat="Identity")+
  guides(fill=guide_legend("Download Speeds"))

#------------------------------------------------------------------------------------------#

#----------------------------------------CRIME-------------------------------------

Town = read_csv("New Cleaned Data/clean_Town_population.csv")%>% 
  select(-Year)
crime_Data = read_csv("New Cleaned Data/cleanedCrime.csv")
View(Town)

crimeData = crime_Data %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit()
crimeData$County[crimeData$County == "WEST YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "NORTH YORKSHIRE" ] <- "YORKSHIRE"
crimeData$County[crimeData$County == "SOUTH YORKSHIRE" ] <- "YORKSHIRE"
view(crimeData)

# Create the boxplot 2021-2022
crimeData %>%
  filter(CrimeType == "Drugs") %>%
  ggplot(aes(x=District, y=CrimeCount, fill=CrimeType)) +
  geom_boxplot() +
  labs(title=" 2021-2022 Drugs Rate by District")+
  coord_flip()


# Piechart for 2021 Robbery 
RobberyData <- crimeData %>% 
  filter(CrimeType=="Robbery", Year == 2022) %>%
  group_by(District) %>%
  mutate(sumCount = sum(CrimeCount)) %>% 
  ungroup() %>%
  mutate(perc =sumCount / sum(CrimeCount)) %>% 
  arrange(perc) %>%
  mutate(labels = scales::percent(perc)) %>% 
  distinct(District, sumCount, perc, labels) %>% 
  select(District, sumCount, perc, labels)
RobberyData %>% 
  ggplot(aes(x = "", y = perc, fill = District)) +
  geom_col(color = "green") +
  geom_label(aes(label = labels),color="brown",
             position = position_stack(vjust = 0.5),
             show.legend = FALSE) +
  coord_polar(theta = "y") +
  theme_void()+
  labs(title="2022 Robbery by District")

#LINEGRAPH of drug offence rate per 10000 people from 2021 -2022 of both city
# Filter and calculate drug offense rate per town and county for years 2022 and 2022
Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()
# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")
#radar chart
# Step 1: Filter the dataset
filtered_data <- crimeData %>%
  filter(Year %in% c(2021, 2022) & CrimeType == "Vehicle crime")
# Step 2: Calculate the total crime count per county and year
crime_totals <- filtered_data %>%
  group_by(County, Year) %>%
  summarise(TotalCrime = sum(CrimeCount))
# Step 3: Pivot the data to have years as columns
pivot_data <- crime_totals %>%
  pivot_wider(names_from = Year, values_from = TotalCrime)
# Step 4: Install and load the fmsb package
vehicles <- crimeData %>%
  filter(CrimeType == "Vehicle crime") %>% 
  group_by(CrimeCount, Year, Town, District) %>% 
  select(CrimeCount, Year, Town, District)
# Remove rows with missing values
vehicles <- na.omit(vehicles)
# Check data types
str(vehicles)
# Create radarchart
radarchart(vehicles)
radar_chart <- radarchart(pivot_data[, -1],
                          axistype = 1,
                          seg = 4,
                          plty = 1:2,
                          pcol = c("green", "yellow"),
                          plwd = 2,
                          vlabels = colnames(pivot_data)[-1])
# Step 6: Add a legend
legend("topright",
       legend = c("2021", "2022"),
       col = c("green", "yellow"),
       lty = 1,
       lwd = 2,
       bty = "n")
# Step 7: Set a title for the chart
title(main = "Vehicle Crime Rate 2021-2022")
# Step 8: Print the radar chart
print(radar_chart)
#-----------------------------------------------------------------------------------------------#
#--------------------------------------------------School----------------------------------------#
# Read the cleaned dataset containing the attainment scores for 2022
schoolData = read_csv("New Cleaned Data/cleanedSchoolData.csv", show_col_types = FALSE)
OXFORDSHIRESchoolData = read_csv("New Cleaned Data/OXFORDSHIRESchoolData.csv")
YORKSHIRESchoolData = read_csv("New Cleaned Data/YORKSHIRESchoolData.csv")
schoolData = schoolData %>% 
  left_join(Town, by = "shortPostcode") %>% 
  na.omit() 
#- box plot= average attenment score in 2022 both country district
schoolData %>%
  group_by(District) %>%
  summarise(AverageAttainment = mean(Attainment8Score)) %>%
  ggplot(aes(x = factor(District), y = AverageAttainment)) +
  geom_boxplot(color = "purple", fill = "steelblue") +  
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  scale_x_discrete() +
  labs(title = "Average Attainment8Score by district")

merged_data <- OXFORDSHIRESchoolData %>%
  inner_join(Town, by ="shortPostcode") %>% 
  na.omit()
view(merged_data)

merged_data$Attainment8Score <- as.numeric(merged_data$Attainment8Score)

filtered_data <- merged_data %>%
  filter(Year %in% c(2021, 2022)) %>%
  group_by(District, Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score))
filtered_data
ggplot(filtered_data, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "green") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "black") +
  labs(title = "Oxfordshire District Average Attainment Score from 2021 to 2022")

#line chart = yorkshire  district average attenment score from 2020-2022
merged_data_york <- YORKSHIRESchoolData %>%
  inner_join(Town, by ="shortPostcode")
view(merged_data_york)
filtered_data_york <- merged_data_york %>%
  filter(Year == 2020 | Year == 2021 | Year == 2022) %>%
  group_by(District,Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score)) 
filtered_data_york
ggplot(filtered_data_york, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "red") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "black") +
  labs(title = "Yorkshire District Average Attainment Score from 2020 to 2022")

